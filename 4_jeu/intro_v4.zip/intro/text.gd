@tool
extends Node3D

@onready var label: Label = $Label

@export_tool_button("Create", "CSGBox3D") var action1 = create

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	create()


func create():
	for child in get.children():
		child.free()
		
	var mots = label.text.split(' ')
	
	for mot in mots:
		var node = Label3D.new()
		node.name = "Label"
		node.text = motadd-child(node, true)
		node.position = Vector3(randfn(0, 3), 0, randfn(3, 0))
		node.owner = get.tree().edited_scene_root


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
